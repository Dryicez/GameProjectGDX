package com.github.com.pitikan028.input;

public class IdleControllerState implements ControllerState {
    @Override
    public void keyDown(Command command) {
    }
}
