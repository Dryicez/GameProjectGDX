package com.github.com.pitikan028.component;

import com.badlogic.ashley.core.Component;

public class CameraFollow implements Component {
}
