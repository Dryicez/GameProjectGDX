package com.github.com.pitikan028.input;

public enum Command {
    LEFT,
    RIGHT,
    DOWN,
    UP,
    SELECT,
    CANCEL
}
